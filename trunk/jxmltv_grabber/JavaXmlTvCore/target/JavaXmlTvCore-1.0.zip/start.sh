#!/bin/sh

echo "Starting grabber"
java -jar lib/JavaXmlTvCore-1.0.jar

